package com.ariemay.coffeeshopmay;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import com.ariemay.coffeeshopmay.R;

public class StartActivity extends AppCompatActivity {
    EditText editNama;
    ImageView arrowImage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        editNama = (EditText) findViewById(R.id.name);
        arrowImage = (ImageView) findViewById(R.id.arrowImage);


        arrowImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //mendapatkan value dari edit nama
                String nama = editNama.getText().toString();

                Intent i = new Intent(getApplicationContext(),
                        com.ariemay.coffeeshopmay.ChartActivity.class);
                // kirim data
                i.putExtra("name", nama);

                startActivity(i);
            }
        });

    }
}
