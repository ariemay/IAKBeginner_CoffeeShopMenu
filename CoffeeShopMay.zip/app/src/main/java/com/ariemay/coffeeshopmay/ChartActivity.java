package com.ariemay.coffeeshopmay;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class ChartActivity extends AppCompatActivity {
    TextView txtNama;
    CheckBox ck1;
    CheckBox ck2;
    Button btnbayar;
    TextView totalHarga;


    int hrKopiToraja = 20000, hrKopiSidikalang = 19000, hrDefault = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chart);

        txtNama = (TextView) findViewById(R.id.name);
        ck1 = (CheckBox) findViewById(R.id.Checkbox_KopiToraja);
        ck2 = (CheckBox) findViewById(R.id.Checkbox_KopiSidikalang);
        btnbayar = (Button) findViewById(R.id.btnbayar);
        totalHarga = (TextView) findViewById(R.id.jumlah_harga);


        String terimaNama = getIntent().getStringExtra("name");

        //set value ke txt nama
        txtNama.setText("Hai " + terimaNama + ", Selamat berbelanja");


        ck1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ck1.isChecked() == true){
                    hrDefault = hrDefault + hrKopiToraja;
                    totalHarga.setText("Rp "+hrDefault);
                }
                else if (ck1.isChecked() == false){
                    hrDefault = hrDefault - hrKopiToraja;
                    totalHarga.setText("Rp "+hrDefault);
                }
            }
        });

        ck2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ck2.isChecked() == true){
                    hrDefault = hrDefault + hrKopiSidikalang;
                    totalHarga.setText("Rp "+hrDefault);
                }
                else if (ck2.isChecked() == false){
                    hrDefault = hrDefault - hrKopiSidikalang;
                    totalHarga.setText("Rp "+hrDefault);
            }
        }});

        btnbayar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Anda harus bayar: "+hrDefault, Toast.LENGTH_LONG).show();
            }
        });
    }

}
